import sys
import pyvisa as visa
from PyQt5 import QtWidgets, uic
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from oscilloscope import Oscilloscope
from fft_processor import FFTProcessor
import pyqtgraph as pg


class OscilloscopeGUI(QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()

        uic.loadUi('oscilloscope.ui', self)
        # uic.loadUi('test.ui', self)

        self.oscilloscope = None
        self.fft_processor = FFTProcessor()

        # UI 요소 설정
        # Connect
        self.is_connected = False
        self.connection_connect_button.clicked.connect(self.connection_connect_device)

        # Time Update
        self.time_update_timer = QTimer()
        self.time_update_timer.start(1000)
        self.time_update_timer.timeout.connect(self.connection_update_current_time)

        # Control
        self.is_acquiring = False
        self.channel_selected = {
            1: False,
            2: False,
            3: False,
            4: False
        }

        self.control_select_channel_ch1.stateChanged.connect(
            lambda: self.control_channel_select(1, self.control_select_channel_ch1.isChecked()))
        self.control_select_channel_ch2.stateChanged.connect(
            lambda: self.control_channel_select(2, self.control_select_channel_ch2.isChecked()))
        self.control_select_channel_ch3.stateChanged.connect(
            lambda: self.control_channel_select(3, self.control_select_channel_ch3.isChecked()))
        self.control_select_channel_ch4.stateChanged.connect(
            lambda: self.control_channel_select(4, self.control_select_channel_ch4.isChecked()))

        self.control_single.clicked.connect(self.control_single_aquire_data)
        self.control_run_stop.clicked.connect(self.control_single_aquire_data)
        self.control_capture_display.clicked.connect(self.control_capture_display)


        # Plots
        self.time_domain_data_graphics_view = pg.PlotWidget()
        self.timeLayout = QVBoxLayout(self.time_domain_data_graphics_view)
        self.timeLayout.addWidget(self.time_domain_data_graphics_view)

        self.result_graphics_view = pg.PlotWidget()
        self.resultLayout = QVBoxLayout(self.result_graphics_view)
        self.resultLayout.addWidget(self.result_graphics_view)

        self.plots_initialize()

        # Toolbar

    # --------------------------------------------------- Connection ------------------------------------------------- #
    def connection_populate_visa_addresses(self):  # 사용 가능한 VISA 주소 콤보 상자를 채우는 함수
        try:
            rm = visa.ResourceManager()
            address = rm.list_resources()
            self.connection_combobox.addItems(address)
        except Exception as e:
            QMessageBox.critical(self, "Address Loading Error", str(e))

    def connection_connect_device(self):  # 선택한 VISA 주소로 연결하는 함수
        try:
            visa_address = self.connection_combobox.currentText()
            self.oscilloscope = Oscilloscope()
            self.oscilloscope.connect_device(visa_address)
            if self.oscilloscope.is_connected:
                self.control_set_btn_on()
                self.connection_status_label.setText("Status: Connected")
                QMessageBox.information(self, "Connection", f"Connected to {self.oscilloscope.scope_idn}")
                self.connect_devide_name_label.setText(f"Device: {self.oscilloscope.scope_idn}")
            else:
                self.connection_status_label.setText("Status: Not Connected")
        except Exception as e:
            QMessageBox.critical(self, "Connection Error", str(e))

    def connection_disconnect_device(self):
        try:
            if self.oscilloscope.is_connected:
                self.oscilloscope.close()
                self.is_connected = False
                self.control_set_btn_off()
                self.connection_device_name_label.setText("Device:")

        except Exception as e:
            QMessageBox.critical(self, "Disconnect Error", str(e))

    def connection_update_current_time(self):  # 현재 시간을 QLabel에 업데이트하는 함수
        current_time = QTime.currentTime().toString("HH:mm:ss")
        self.connection_current_time_label.setText("Current Time: "+str(current_time))

    # ----------------------------------------------------- Control -------------------------------------------------- #

    def control_set_btn_on(self):
        try:
            self.control_single.setEnabled(True)
            self.control_run_stop.setEnabled(True)
            self.control_capture_display.setEnabled(True)
        except Exception as e:
            QMessageBox.critical(self, "Button Setting Error", str(e))

    def control_set_btn_off(self):
        try:
            self.control_single.setEnabled(False)
            self.control_run_stop.setEnabled(False)
            self.control_capture_display.setEnabled(False)
        except Exception as e:
            QMessageBox.critical(self, "Button Setting Error", str(e))

    def control_channel_select(self, channel_num, checked):
        try:
            self.channel_selected[channel_num] = checked
        except Exception as e:
            QMessageBox.critical(self, "Channel Selecting Error", str(e))

    def control_single_aquire_data(self):
        try:
            if not self.is_acquiring:
                if self.oscilloscope:
                    self.oscilloscope.acquire_data(self.channel_selected)

        except Exception as e:
            QMessageBox.critical(self, "Data Aquiration Error", str(e))

    def control_capture_display(self):
        try:
            self.oscilloscope.captrue_display()
        except Exception as e:
            QMessageBox.critical(self, "Display Capture Error", str(e))


    '''
    def control_toggle_acquire_data(self):  # 오실로스코프에서 데이터 수집을 토글하는 함수
        if not self.is_acquiring:
            if self.oscilloscope:
                self.control_start_data_acquisition()
        else:
            self.control_stop_data_acquisition()

    def control_start_data_acquisition(self):  # 데이터 수집 프로세스를 시작하는 함수
        self.connection_status_label.setText("Status: Data Acquiring")
        self.is_acquiring = True
        self.timer.start(1000)  # 매초 데이터 수집 시작


    def control_stop_data_acquisition(self):  # 데이터 수집 프로세스를 중지하는 함수
        self.connection_status_label.setText("Status: Stanby")
        self.is_acquiring = False
        self.timer.stop()  # 타이머 중지

    def control_start_acquisition_loop(self):  # 데이터 수집을 위한 루프를 시작하는 함수
        if self.is_acquiring:
            try:
                self.oscilloscope.acquire_data()  # 데이터 수집
                self.plot_signals()  # 플로팅
            except Exception as e:
                QMessageBox.critical(self, "Aquiring Error", str(e))
                '''

    # ------------------------------------------------------ Math ---------------------------------------------------- #
    def math_select_channel(self):
        return

    # ------------------------------------------------------ Plots --------------------------------------------------- #
    def plots_initialize(self):
        """그래프에 기본 제목과 레이블을 설정합니다."""
        # 시간 도메인 그래프 초기 설정
        self.time_domain_data_graphics_view.setTitle("Time Domain Signal")
        self.time_domain_data_graphics_view.setLabel('left', 'Voltage (V)')
        self.time_domain_data_graphics_view.setLabel('bottom', 'Time (s)')
        self.time_domain_data_graphics_view.showGrid(x=True, y=True)

        self.time_domain_data_graphics_view.plot([], [], pen='y')

        # 결과 그래프 초기 설정
        self.result_graphics_view.setTitle("Result")
        self.result_graphics_view.setLabel('left', '')
        self.result_graphics_view.setLabel('bottom', '')
        self.result_graphics_view.showGrid(x=True, y=True)

        self.result_graphics_view.plot([], [], pen='r')

    def plot_signals(self):
        """수집된 신호와 FFT 결과를 플로팅합니다."""
        try:
            if self.oscilloscope:
                self.time_domain_data_graphics_view.clear()
                self.time_domain_data_graphics_view.plot(self.oscilloscope.scaled_time, self.oscilloscope.scaled_wave,
                                                         pen='y', name='Signal')
                self.time_domain_data_graphics_view.addLegend()  # 그래프에 라벨링 추가
                self.time_domain_data_graphics_view.setTitle("Time Domain Signal")
                self.time_domain_data_graphics_view.setLabel('left', 'Voltage (V)')
                self.time_domain_data_graphics_view.setLabel('bottom', 'Time (s)')

                use_dbv = self.dBVRadio.isChecked()
                self.fft_processor.perform_fft(self.oscilloscope.tscale, self.oscilloscope.scaled_wave, use_dbv)
                freq_domain, magnitude = self.fft_processor.get_results()

                self.freqPlotWidget.clear()
                self.freqPlotWidget.plot(freq_domain, magnitude, pen='r', name='FFT')
                self.freqPlotWidget.addLegend()
                self.freqPlotWidget.setTitle("Frequency Domain Signal")
                self.freqPlotWidget.setLabel('left', 'dBV RMS (mV)' if use_dbv else 'Linear RMS (mV)')
                self.freqPlotWidget.setLabel('bottom', 'Frequency (Hz)')
        except Exception as e:
            QMessageBox.critical(self, "플로팅 오류", str(e))

    def update_measurement_results(self, measurement_type, result):
        """측정 결과를 테이블에 업데이트합니다."""
        row_position = self.resultsTable.rowCount()
        self.resultsTable.insertRow(row_position)
        self.resultsTable.setItem(row_position, 0, QtWidgets.QTableWidgetItem(measurement_type))
        self.resultsTable.setItem(row_position, 1, QtWidgets.QTableWidgetItem(str(result)))

    # ---------------------------------------------------- Tool bar -------------------------------------------------- #
    def close(self):
        if self.is_connected:
            self.oscilloscope.close()
            self.rm.close()
            self.is_connected = False
            print("Connection closed.")


if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    window = OscilloscopeGUI()
    window.connection_populate_visa_addresses()
    window.setWindowTitle("Oscilloscope GUI")  # 창 제목 설정
    window.show()
    sys.exit(app.exec_())

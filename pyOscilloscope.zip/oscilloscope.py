import numpy as np
import pyvisa as visa
from PyQt5.QtWidgets import QMessageBox
import time


# Data Acquisition Class
class Oscilloscope:
    def __init__(self):
        super().__init__()
        self.scope_idn = None
        self.is_connected = False

    def connect_device(self, visa_address):
        try:
            self.rm = visa.ResourceManager()
            self.scope = self.rm.open_resource(visa_address)
            self.scope.timeout = 10000  # ms
            self.scope.encoding = 'UTF-8'
            self.scope.read_termination = '\n'
            self.scope.write_termination = None
            self.scope.write('*cls')  # Clear ESR
            self.scope_idn = self.scope.query('*idn?')  # Identify the oscilloscope
            print(self.scope_idn)
            self.is_connected = True
            self.configure_io()
        except Exception as e:
            QMessageBox.critical(None, "Connection Error", f"Failed to connect to oscilloscope: {str(e)}")

    def configure_io(self):
        try:
            self.scope.write('header 0')
            self.scope.write('data:encdg SRIBINARY')
            self.scope.write('data:source CH1')
            record = int(self.scope.query('horizontal:recordlength?'))
            self.scope.write('data:start 1')
            self.scope.write(f'data:stop {record}')
            self.scope.write('wfmoutpre:byt_n 1')
        except Exception as e:
            QMessageBox.critical(None, "Configuration Error", f"Oscilloscope configuration failed: {str(e)}")

    def acquire_data(self, channels):
        if not self.is_connected:
            QMessageBox.critical(None, "Connection Error", "Data cannot be acquired before the oscilloscope is connected")
            return  # Return if the oscilloscope is not connected

        try:
            # Start acquisition
            self.scope.write('ACQuire:STAte 1')  # Start acquisition
            self.bin_wave = self.scope.query_binary_values('curve?', datatype='b', container=np.array)
            self.retrieve_scaling_factors()
            self.scale_data()
        except visa.VisaIOError as e:
            QMessageBox.critical(None, "VISA Error", f"Error during acquisition: {str(e)}")
        except Exception as e:
            QMessageBox.critical(None, "Acquisition Error", f"Data acquisition failed: {str(e)}")

    def retrieve_scaling_factors(self):
        try:
            self.tscale = float(self.scope.query('wfmoutpre:xincr?'))
            self.tstart = float(self.scope.query('wfmoutpre:xzero?'))
            self.vscale = float(self.scope.query('wfmoutpre:ymult?'))
            self.voff = float(self.scope.query('wfmoutpre:yzero?'))
            self.vpos = float(self.scope.query('wfmoutpre:yoff?'))
        except visa.VisaIOError as e:
            QMessageBox.critical(None, "Scaling Error", f"Error retrieving scaling factors: {str(e)}")
        except Exception as e:
            QMessageBox.critical(None, "Scaling Error", f"Failed to retrieve scaling factors: {str(e)}")

    def scale_data(self):
        try:
            record = int(self.scope.query('horizontal:recordlength?'))
            total_time = self.tscale * record
            self.tstop = self.tstart + total_time
            self.scaled_time = np.linspace(self.tstart, self.tstop, num=record, endpoint=False)
            unscaled_wave = np.array(self.bin_wave, dtype='double')
            self.scaled_wave = (unscaled_wave - self.vpos) * self.vscale + self.voff
        except Exception as e:
            QMessageBox.critical(None, "Scaling Error", f"Data scaling failed: {str(e)}")

    def run_acquisition_loop(self):
        """ Continuously acquire data in a loop. """
        while self.is_connected:
            self.acquire_data()

    def captrue_display(self):
        try:
            print("111111111111111111111")
            self.scope.write(":DISPlay:IMAGe:FORMat PNG")
            response = self.scope.query(':DISPlay:DATA?', datatype='B', is_big_endian=True)
            print("22222222222222222222222222")
            header = response[:2]  # 이미지 수신 처리
            if header[0] == ord('#'):
                num_digits = response[1]
                data_length = int(''.join([chr(b) for b in response[2:2 + num_digits]]))
                image_data = response[2 + num_digits:2 + num_digits + data_length]

                print("333333333333333333")

                with open(f'image_{time.strftime('%Y-%m-%d %H:%M:%S')}.png', 'wb') as f:  # 이미지 파일로 저장
                    f.write(bytearray(image_data))
                QMessageBox.critical(None, "Captrue Display", f"Image Successfully Saved")
            else:
                QMessageBox.critical(None, "Captrue Display - Image Save Error", f"Unexpected data format received")

        except IOError as e:
            QMessageBox.critical(None, "Captrue Display - Image Save Error", f"Image Save Failed: {str(e)}")
        except Exception as e:
            QMessageBox.critical(None, "Display Capture Error", f"Display Capture Failed: {str(e)}")

    def close(self):
        self.scope.close()
        self.is_connected = False
